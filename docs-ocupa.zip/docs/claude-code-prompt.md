Work in this order and check each part before moving on: A, then B, then C. If part B (PDF) or part C (levels) is already implemented in the code, do not redo it: just check it matches this file and restyle it to the new look.

Do three things in the Tombi app: (A) restyle all the adult screens to match the Ocupa system design and rebuild the home screen as an Ocupa-style dashboard, (B) add a real PDF download to every report, and (C) save each child's progress and raise or lower the difficulty of each task per child. The visual reference is `docs/home-ocupa.png` and `docs/home-ocupa-mockup.html` (open both and match them closely). This replaces any earlier home screen design completely, including the dark green hero.

## Hard limits
- Do NOT edit `js/tombi.js`, `js/audio.js` or `js/dsp.js`. Do not change the dragon, its eyes or mouth, or how the child's game screen (`#screen-game`) looks: it keeps its dark forest look and gets NO sidebar or top bar. In `js/stages.js` change only the task parameters described in part C (patterns, thresholds, story, timing, targets), not the visuals or Tombi's behaviour.
- Keep all existing data readable: old children have no `levels`, old sessions have no `level` fields. Treat missing values as level 1 / unknown, never crash.
- Keep the existing button ids working (`#btn-add-child`, `#btn-settings`) and the existing navigation functions (`openPrep`, `openReport`, `openChildForm`, `show`).
- Plain HTML/CSS/JS, no frameworks, no build step. The only new dependency is html2pdf.js from cdnjs (part B). RTL Hebrew, keep `esc()` on every user string.
- All copy in Hebrew, matching the tone already in the app.

# Part A: Ocupa look and home screen

## Design tokens (Ocupa)
Add these to `:root` and use them for every adult screen (home, child form, prep, done, report, settings, modal). Keep the old tokens only for the game screen.
`--navy:#10283E; --navy-2:#174351; --navy-3:#1D394D; --nav-text:#C9D6E2; --teal:#2F9A8B; --teal-2:#2FAA96; --teal-soft:#EEF8F3; --pink:#D96AA8; --pink-soft:#FBEAF3; --amber:#E9A23B; --amber-soft:#FDF1DC; --red:#B4473A; --red-soft:#F4DCD9; --bg:#F6F8F7; --card:#FFFFFF; --ink:#1B2733; --muted:#6B7783; --line:#E6EAEC; --lav:#F3ECF8; --peach:#FBF3EF;`
- Font: Assistant from Google Fonts (400, 500, 600, 700, 800) for all adult screens; replace Fredoka/Rubik there.
- Buttons: 40px high, radius 9px, teal fill with white bold text; secondary = white with teal text and a light teal border; small = 34px. Icon buttons: 38px square, radius 9px, 1px `--line` border, white.
- Cards: white, radius 12px, shadow `0 1px 3px rgba(16,40,62,.08)`, optional 4px coloured stripe on the inline-start side (`border-inline-start`, appears on the right in RTL). Card header: small coloured line icon + bold title (800) + muted sub-line, and a small muted label on the opposite side. Card footer: a thin top border, a teal bold text link with "‹" on one side and muted text or actions on the other.
- Tags: small pills (0.74rem, bold): teal-soft/teal, amber-soft/brown, red-soft/red, gray.
- Page background `--bg`. Focus ring: 2px teal outline with offset.

## App shell (all adult screens, not the game)
- **Sidebar** on the right (RTL), 248px, `--navy` background, full height, sticky:
  - The Ocupa logo at the top, centred, as this inline SVG (keep it exactly): `<svg viewBox="0 0 150 44" width="170" height="50" aria-hidden="true"><g fill="none" stroke="#fff" stroke-width="1.8" stroke-linejoin="round"><rect x="2" y="21" width="19" height="19"/><circle cx="31" cy="30.5" r="9.5"/><path d="M21 2 L31 20 L11 20 Z"/></g><text x="45" y="39" fill="#fff" font-family="Arial Rounded MT Bold, Arial, sans-serif" font-weight="700" font-size="30" letter-spacing="-0.5">ocupa</text></svg>`
  - A "מפגש חדש +" button (`--navy-2` background, 1px `#2B5C67` border, radius 10px, white bold): opens prep for the "next" child (see below), or the new child form when there are no children.
  - Nav items (icon + label, radius 10px, `--nav-text`; active item `--navy-3` background, white bold): "טומבי" with the small round Tombi image and a teal pill "משחק" (active on home), "הילדים" (goes to home and scrolls to the children section, shows the count), "דוחות" (goes to home and scrolls to the children section), "הגדרות" (`show('settings')`, active on settings).
  - Under 900px the sidebar collapses into a top navy bar with the logo and a menu button that opens it as a drawer.
- **Top bar**: white, 64px, bottom border `--line`. Breadcrumb on the right: "Ocupa ‹ טומבי" on home, "Ocupa ‹ טומבי ‹ {screen name}" on other screens (muted, current item bold). On the left, icon buttons: backup (download arrow, same export as `#s-export`; when there are sessions and the last backup is 14+ days old or never, show a 12px amber dot on its corner and set title/aria-label to "גיבוי אחרון לפני N ימים" / "עוד לא נעשה גיבוי"), settings (gear), help (question mark, opens a short modal that explains the session and the aide panel). Save `T.store.settings.lastBackupAt = Date.now()` (then `T.store.save()`) whenever export succeeds.
- Content area max-width 1150px, centred, padding 26px 34px. The existing back links (`.back`) stay but use the teal colour.
- Restyle the other adult screens (child form, prep steps, done, report, settings, modal) with the same tokens, cards, buttons and fonts. Do not change their content or logic, except what parts B and C add.

## Home screen, top to bottom
1. **Greeting banner**: radius 16px, `linear-gradient(180deg, var(--lav), var(--peach))`, padding 26px 32px. On the right, the Tombi image in a 118px circle (`object-position: 52% 38%`, 5px white ring and soft shadow). Text: muted date line ("יום חמישי · 22 באוקטובר", from today with `toLocaleDateString('he-IL', {weekday:'long', day:'numeric', month:'long'})`), H1 "מי משחק היום עם טומבי?" (2rem, 800), a sub-line "מפגש קולי של 8–10 דקות. הקול הוא רק דרך התגובה, ומה שנמדד הוא ויסות, הדרגה, תזמון ועכבה.", then buttons: teal "▶ להמשיך עם {name}" for the "next" child (the child with the most recent session, falling back to the first child; hidden when there are no children) calling `openPrep(child)`, and secondary "+ ילד חדש" (`#btn-add-child`). Under them a muted row "מסלול המפגש:" with small white translucent pills: 🐢🐟🐒 מנוע · 🥁 הד קולי · 🐭🦁 עכבר ואריה · 🐸 מילת קסם · 🐍 נחש · 🐢🐟🐒 מנוע.
2. **Two summary cards side by side** (one column under 900px). Hide both when there are no sessions at all. Ignore sessions with `mode === 'sim'`.
   - "מעקב מפגשים" (teal stripe, calendar icon, sub-line "השבוע · {date range}", label "מתחילת השבוע"): a 96px ring (SVG circle, teal) with the percent of a weekly goal (default 6 sessions, editable in settings as "יעד מפגשים שבועי") and "מהיעד" under it; next to it rows with a bottom border: "מפגשים" `4 מתוך 6`, "דקות משחק" (sum of `durationSec`/60, rounded), "ילדים פעילים" (children with a session in the last 30 days). Footer: link "לכל המפגשים ‹" (scrolls to the children) and muted "ממוצע X דק׳ למפגש". There is NO overall or monthly score anywhere: scores are only per child.
   - "דורש תשומת לב" (pink stripe, warning icon, sub-line "מה כדאי לעשות היום", red tag "N פתוחים"): a list (max 4 items, each with a 36px round initials avatar, bold name, muted reason, and an action on the left): children with 14+ days since the last session (action link "להתחיל ‹" → `openPrep`), children whose last session raised a level (amber tag "⬆ שלב חדש"), children whose last session lowered a level (gray tag "שלב קל יותר"), and the backup reminder when due (action "לגבות ‹"). When the list is empty show a friendly muted line "הכול מעודכן. אין משהו דחוף היום."
3. **Section bar**: people icon (teal) + "הילדים" (1.3rem, 800) + muted count. On the left a search field (38px, radius 9px, filters by name live) and a segmented control with a 1px border: אחרונים (default) / א–ב (`localeCompare('he')`) / צריך מפגש; the active segment is teal-soft with teal bold text. Remember the sort in `localStorage` inside try/catch. Show search and sort only with 4+ children.
4. **Children grid**: 2 columns (1 under 900px). Each child is a card with a coloured stripe; the colour is picked deterministically from `[--teal, --pink, #3550B8, #E07A3F, #7A5BC7]` by hashing the child id, and the same colour is used for that child's avatar, ring and sparkline.
   - Header: 42px round avatar with the first two letters of the name on a light tint of the child colour; bold name; tags: "הבא בתור" (teal) on the next child, "דוגמה" (gray) for sample children, "ללא מילים" (gray) for `nonverbal`, red "N יום בלי מפגש" when 14+ days. Muted sub-line "גיל X · N מפגשים · אחרון {relative date}" (היום / אתמול / לפני N ימים, full date after 30 days). Muted label "מפגש אחרון" on the other side.
   - Body: on the right a 96px ring in the child colour showing the last session score (`sessionScore`) with the change vs 3 sessions ago under it ("↑ 13" teal / "↓ 4" red), and under the ring a small sparkline (all sessions, time left to right, 2px line in the child colour, `vector-effect: non-scaling-stroke`). On the left four rows with a bottom border: תזמון (echo), הדרגה (loudness), עכבה (magic), משך (snake); each row shows the task name, a small teal-soft badge "שלב N" with the child's CURRENT level (amber with "⬆" if it just went up), and the 0–100 score in bold on the far side ("—" when skipped or missing).
   - Engine line (muted): "מנוע: 🐒 קוף ← 🐟 דג" from `stages.engineStart.choice` / `engineEnd.choice` (turtle 🐢 צב, fish 🐟 דג, monkey 🐒 קוף).
   - Footer: link "לדוח התקדמות ‹" (`openReport`) on the right; on the left a PDF icon button (file with a down arrow, `aria-label="הורדת הדוח כ-PDF"`, see part B, disabled with no sessions), an edit icon button (pencil, `openChildForm`), and a small teal button "▶ התחלת מפגש" (`openPrep`).
   - A child with 0 sessions: an empty grey ring with "—" and the line "עוד לא היה מפגש. טומבי מחכה!" instead of the rows.
   - The last cell is a dashed "add" card (2px dashed `#D5DEE2`, radius 12px): a 46px teal-soft circle with "+", bold "ילד חדש", muted "שם, גיל, ואם צריך מסלול ללא מילים". Opens `openChildForm(null)`.
5. **Empty state** (no children): instead of the summary cards and the grid, one centred card with the Tombi image, "עוד אין ילדים", a short muted text, and the buttons "ילד חדש" and "ילד לדוגמה" (keep the current `T.report.makeSample()` behaviour).
6. There is NO privacy or "recordings are not saved" note on the home screen. Remove the old `.privacy` paragraph.

## Session score
`sessionScore(s)` = mean of `score` over `echo`, `loudness`, `magic`, `snake` that exist and are not `skipped`; `null` if none. Use `T.store.sessionsOf(id)` (already sorted by date). Put these helpers next to `renderHome()`.

# Part B: PDF download for every report

- Add `html2pdf.js` from cdnjs: `<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js" defer></script>` in `index.html`.
- Create `T.pdf.download(element, filename)` in a new small file `js/pdf.js`: A4 portrait, 12mm margins, `html2canvas: { scale: 2, useCORS: true }`, `pagebreak: { mode: ['css', 'legacy'], avoid: ['.chart', 'tr', '.card'] }`. While rendering, add a `pdf-mode` class to the element that hides `.no-print` items, uses white background, and keeps RTL. Show a "מכין PDF…" state on the clicked button and restore it after. If `html2pdf` is not available (offline), fall back to `window.print()` and show a short note "אין חיבור לאינטרנט, נפתח חלון הדפסה. בוחרים שם 'שמירה כ-PDF'".
- File name: `טומבי - {child name} - דוח התקדמות - {YYYY-MM-DD}.pdf` (strip characters not allowed in file names).
- Where to offer it, next to the existing print button and with the same style:
  1. The progress report screen (`report.js` `.report-actions`): new primary button "הורדת PDF" (`data-act="pdf"`), handled in `app.js` next to `print`. Keep "הדפסה" as a secondary button.
  2. The home child card PDF icon: render the report for that child into a hidden off-screen container (`position:fixed; left:-10000px; width:794px`) with `T.report.render(child, el)`, download, then remove the container. Do not navigate away from home.
  3. The "המפגש נשמר" (done) screen: a button "הורדת סיכום המפגש כ-PDF" that downloads `#done-body` with a header (Tombi logo, child name, date) as `טומבי - {name} - מפגש {date}.pdf`.
- The PDF header on every report: small Tombi image, "טומבי · דוח התקדמות", child name, age, date range of the sessions, and the current level per task. Make sure the charts (SVG) and Hebrew text render correctly and nothing is cut at page breaks.
- Keep hiding download buttons when `window.TOMBI_DEMO` is set, like the other download actions.

# Part C: per-child progress and adaptive difficulty

Every child keeps their own level (1 to 5) for each of the four scored tasks, and the next session uses that level.

## Data
- `child.levels = { echo: 1, loudness: 1, magic: 1, snake: 1 }` (default for new children; for existing children with sessions, compute a starting level once from their last two sessions with the rule below).
- `child.levelLock = { echo: false, ... }`: when true, the level does not change automatically.
- Each session stage result stores the level it was played at: `rec.stages.echo.level = 2`, etc. After the session store the changes: `rec.levelChanges = [{ task: 'echo', from: 2, to: 3 }]`.
- Put the logic in a new file `js/levels.js` exposing `T.levels = { get(child, task), params(task, level, child), updateAfterSession(child, rec), NAMES }`, loaded before `stages.js`.

## Rule (between sessions)
For each task, after the session is saved (skip `mode === 'sim'` and sample sessions):
- Level UP by 1 when the last 2 real sessions at the current level both scored 80 or more on that task.
- Level DOWN by 1 when the last 2 real sessions at the current level both scored under 40, or the aide gave physical help in that task in both.
- Otherwise stay. Never go below 1 or above 5. Skipped stages do not count.
- Nonverbal children use the same levels (with claps / any sound).

## What each level changes (in `stages.js`, read from `T.levels.params(task, level, child)`)
- **Echo / תזמון**: L1: 3 patterns of 2 to 3 even beats, slow (600ms). L2: the current 4 patterns. L3: 5 patterns, up to 4 beats, one uneven rhythm. L4: 5 patterns, 4 to 5 beats, two uneven rhythms. L5: same as L4 but 20% faster. Keep the scoring formula.
- **Mouse and lion / הדרגה**: the dB difference that gives 100 points: L1 6dB, L2 8dB (current), L3 10dB. L4 adds a middle animal "חתול" (🐱, medium voice) between the mouse and lion, scored on keeping the order mouse < cat < lion. L5: the child must hold the lion voice (and the mouse voice) steady for 2 seconds, scored on the dB variation.
- **Magic word / עכבה**: L1: 8 story lines, 3 frogs, response window 3.5s. L2: the current 12-line story. L3: 14 lines with 2 lure lines that sound similar (for example "צפור", "צפצוף") and a 2.6s window. L4: 16 lines, 4 lures, 2.2s window, faster speech. L5: add the rule "when the frog is sleeping (צפרדע ישנה) we stay quiet", scored as an extra no-go. Write the extra story lines in the same style as the existing `STORY`, each with its own audio key so recorded lines keep working.
- **Snake / משך**: target seconds = age-based base (`age - 1`, min 3) at L1, plus 1 second per level above 1 (so L2 is about the current target), max 12. A non-zero `settings.snakeTarget` still overrides it.
- Scores stay 0 to 100 at every level, so a score of 70 at level 3 is better than 70 at level 1. Everywhere a score is shown in the report, also show the level ("70 · שלב 3").

## Where the levels appear
- Home card: the "שלב N" badges and the level-up tag from part A.
- Done screen: after a session, one friendly line per change, for example "⬆ נועה עלתה לשלב 3 בתזמון" or "נועה תשחק בשלב 1 בהדרגה בפעם הבאה, כדי שיהיה לה כיף להצליח".
- Report: a small "שלבים" table (task, current level, date reached), level markers on the score charts (a thin vertical line with "שלב 3" where the level changed), and the level column in the sessions table. The same goes into the PDF.
- Child form (edit): a "רמת קושי" section with, for each task, a 1 to 5 stepper and a "לנעול" checkbox, so the therapist can set or freeze a level by hand.
- Aide panel during the session: show the current task level next to the stage name ("הד קולי · שלב 3"), nothing more. The child still sees only Tombi.
- `makeSample()` creates a sample child whose levels rise over the 8 sessions, so the demo shows the feature.


# Quality bar (all parts)
- Buttons and clickable rows at least 40px tall on desktop and 44px on touch, visible focus ring, colour contrast AA, `aria-label` on icon-only buttons, the decorative Tombi images `alt=""`.
- Responsive: under 900px the sidebar becomes a top bar with a drawer, summary cards and the children grid go to one column, the search takes full width. No horizontal scroll at 360px.
- Subtle motion only: cards get a slightly stronger shadow on hover; respect `prefers-reduced-motion`.
- The PDF reports (part B) use the Ocupa look too: Assistant font, teal headings, the Ocupa logo small at the top next to "טומבי · דוח התקדמות".
- Must still work with `window.TOMBI_DEMO` and `window.TOMBI_IMG` (set every Tombi `<img>` on the adult screens from `IMG`).

When done, open the app and check: the home screen with the sample child, with several children, and with no children, at 1440px, 1024px and 390px wide (fix anything that overflows); every adult screen has the sidebar and top bar and the game screen does not; a PDF downloaded from the report screen, from a home card and from the done screen opens with correct Hebrew and charts; a full simulated session at each level runs without errors; and two simulated high-score sessions raise a level (temporarily allow sim sessions in the rule to test it, then turn that off).
